package com.rexxplayz.cavebuddy.client;

import com.rexxplayz.cavebuddy.CaveBuddyMod;
import com.rexxplayz.cavebuddy.entity.CaveBuddyEntity;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;

public class CaveBuddyRenderer extends MobRenderer<CaveBuddyEntity, CaveBuddyModel> {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(CaveBuddyMod.MOD_ID, "textures/entity/cave_buddy.png");

    public CaveBuddyRenderer(EntityRendererProvider.Context context) {
        super(context, new CaveBuddyModel(context.bakeLayer(CaveBuddyModel.LAYER)), 0.25F);
    }

    @Override
    public ResourceLocation getTextureLocation(CaveBuddyEntity entity) {
        return TEXTURE;
    }
}
