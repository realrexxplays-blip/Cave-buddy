package com.rexxplayz.cavebuddy;

import com.rexxplayz.cavebuddy.entity.CaveBuddyEntity;
import com.rexxplayz.cavebuddy.item.BuddyWhistleItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.javafmlmod.FMLJavaModLoadingContext;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(CaveBuddyMod.MOD_ID)
public final class CaveBuddyMod {
    public static final String MOD_ID = "cavebuddy";

    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(Registries.ENTITY_TYPE, MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);

    public static final DeferredHolder<EntityType<?>, EntityType<CaveBuddyEntity>> CAVE_BUDDY =
            ENTITY_TYPES.register("cave_buddy", () ->
                    EntityType.Builder.of(CaveBuddyEntity::new, MobCategory.CREATURE)
                            .sized(0.48F, 0.48F)
                            .clientTrackingRange(8)
                            .build("cavebuddy:cave_buddy"));

    public static final DeferredHolder<Item, Item> CAVE_BUDDY_SPAWN_EGG =
            ITEMS.register("cave_buddy_spawn_egg", () ->
                    new SpawnEggItem(CAVE_BUDDY.get(), 0x526B65, 0xE4C77A, new Item.Properties()));

    public static final DeferredHolder<Item, Item> BUDDY_WHISTLE =
            ITEMS.register("buddy_whistle", () -> new BuddyWhistleItem(new Item.Properties().stacksTo(1)));

    public CaveBuddyMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITY_TYPES.register(modBus);
        ITEMS.register(modBus);
        modBus.addListener(this::addCreativeItems);
    }

    private void addCreativeItems(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            event.accept(CAVE_BUDDY_SPAWN_EGG);
        }
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(BUDDY_WHISTLE);
        }
    }
}
