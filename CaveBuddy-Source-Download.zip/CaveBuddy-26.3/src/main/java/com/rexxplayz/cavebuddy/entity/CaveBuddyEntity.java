package com.rexxplayz.cavebuddy.entity;

import com.rexxplayz.cavebuddy.CaveBuddyMod;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;

import java.util.List;
import java.util.UUID;

public class CaveBuddyEntity extends TamableAnimal {
    private int warningCooldown = 0;
    private int chirpCooldown = 0;

    public CaveBuddyEntity(EntityType<? extends TamableAnimal> type, Level level) {
        super(type, level);
        this.setTame(false);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new SitWhenOrderedToGoal(this));
        this.goalSelector.addGoal(2, new FollowOwnerGoal(this, 1.15D, 2.0F, 8.0F));
        this.goalSelector.addGoal(6, new RandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide || !this.isTame() || this.getOwnerUUID() == null) return;

        if (warningCooldown > 0) warningCooldown--;
        if (chirpCooldown > 0) chirpCooldown--;

        if (warningCooldown <= 0) {
            Player owner = this.level().getPlayerByUUID(this.getOwnerUUID());
            if (owner instanceof ServerPlayer serverPlayer && owner.distanceToSqr(this) < 24 * 24) {
                String warning = findNearbyDanger();
                if (warning != null) {
                    serverPlayer.displayClientMessage(Component.literal("§eCave Buddy chirps: §f" + warning), true);
                    this.level().playSound(null, this.blockPosition(), SoundEvents.ALLAY_AMBIENT_WITH_ITEM,
                            SoundSource.NEUTRAL, 0.55F, 1.25F);
                    warningCooldown = 100;
                }
            }
        }
    }

    private String findNearbyDanger() {
        AABB area = this.getBoundingBox().inflate(8.0D, 4.0D, 8.0D);
        List<Monster> hostiles = this.level().getEntitiesOfClass(Monster.class, area,
                mob -> mob.isAlive() && mob.distanceToSqr(this) < 64.0D);
        if (!hostiles.isEmpty()) return "Something hostile is close!";

        BlockPos origin = this.blockPosition();
        for (BlockPos pos : BlockPos.betweenClosed(origin.offset(-4, -2, -4), origin.offset(4, 2, 4))) {
            if (this.level().getBlockState(pos).is(Blocks.LAVA)) return "Careful! Lava is nearby!";
        }

        if (this.level().getMaxLocalRawBrightness(origin) <= 3) {
            return "It's very dark here. Watch your step!";
        }
        return null;
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);

        if (!this.isTame() && held.is(Items.GLOW_BERRIES)) {
            if (!this.level().isClientSide) {
                if (!player.getAbilities().instabuild) held.shrink(1);
                if (this.random.nextInt(3) == 0) {
                    this.tame(player);
                    this.setOrderedToSit(false);
                    this.level().playSound(null, this.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME,
                            SoundSource.NEUTRAL, 0.8F, 1.5F);
                    player.displayClientMessage(Component.literal("§aYour Cave Buddy trusts you now!"), true);
                } else {
                    this.level().playSound(null, this.blockPosition(), SoundEvents.ALLAY_AMBIENT_WITHOUT_ITEM,
                            SoundSource.NEUTRAL, 0.7F, 0.9F);
                }
            }
            return InteractionResult.SUCCESS;
        }

        if (this.isTame() && this.isOwnedBy(player) && held.isEmpty()) {
            if (!this.level().isClientSide) {
                this.setOrderedToSit(!this.isOrderedToSit());
                this.level().playSound(null, this.blockPosition(), SoundEvents.ALLAY_AMBIENT_WITHOUT_ITEM,
                        SoundSource.NEUTRAL, 0.6F, this.isOrderedToSit() ? 0.8F : 1.3F);
            }
            return InteractionResult.SUCCESS;
        }
        return super.mobInteract(player, hand);
    }

    public void whistleTo(Player player) {
        if (this.isTame() && this.isOwnedBy(player)) {
            this.setOrderedToSit(false);
            this.getNavigation().moveTo(player, 1.35D);
            this.level().playSound(null, this.blockPosition(), SoundEvents.NOTE_BLOCK_BELL.value(),
                    SoundSource.NEUTRAL, 0.8F, 1.4F);
        }
    }

    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob otherParent) {
        return CaveBuddyMod.CAVE_BUDDY.get().create(level);
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return stack.is(Items.GLOW_BERRIES);
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return !this.isTame();
    }

    @Override
    public boolean canBeLeashed() {
        return true;
    }
}
