package com.rexxplayz.cavebuddy.client;

import com.rexxplayz.cavebuddy.CaveBuddyMod;
import com.rexxplayz.cavebuddy.entity.CaveBuddyEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class CaveBuddyModel extends EntityModel<CaveBuddyEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(CaveBuddyMod.MOD_ID, "cave_buddy"), "main");

    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart leftWing;
    private final ModelPart rightWing;
    private final ModelPart tail;

    public CaveBuddyModel(ModelPart root) {
        this.body = root.getChild("body");
        this.head = root.getChild("head");
        this.leftWing = root.getChild("left_wing");
        this.rightWing = root.getChild("right_wing");
        this.tail = root.getChild("tail");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-4, -3, -5, 8, 6, 10), PartPose.offset(0, 18, 0));
        root.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 17).addBox(-3, -3, -3, 6, 6, 6)
                .texOffs(24, 17).addBox(-1, -1, -5, 2, 2, 2)
                .texOffs(24, 25).addBox(-1, 1, -2, 2, 2, 2), PartPose.offset(0, 14, -4));
        root.addOrReplaceChild("left_wing", CubeListBuilder.create()
                .texOffs(32, 0).addBox(0, -1, -3, 1, 5, 6), PartPose.offset(4, 17, 0));
        root.addOrReplaceChild("right_wing", CubeListBuilder.create()
                .texOffs(32, 0).addBox(-1, -1, -3, 1, 5, 6), PartPose.offset(-4, 17, 0));
        root.addOrReplaceChild("tail", CubeListBuilder.create()
                .texOffs(46, 0).addBox(-2, -1, 0, 4, 2, 5), PartPose.offset(0, 18, 4));
        return LayerDefinition.create(mesh, 64, 32);
    }

    @Override
    public void setupAnim(CaveBuddyEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
        head.xRot = headPitch * Mth.DEG_TO_RAD;
        float flap = Mth.cos(ageInTicks * 1.5F) * 0.25F;
        leftWing.zRot = flap;
        rightWing.zRot = -flap;
        body.y = 18.0F + Mth.sin(ageInTicks * 0.12F) * 0.35F;
        tail.xRot = 0.15F + Mth.sin(ageInTicks * 0.18F) * 0.08F;
    }
}
