package com.rexxplayz.cavebuddy.item;

import com.rexxplayz.cavebuddy.entity.CaveBuddyEntity;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

public class BuddyWhistleItem extends Item {
    public BuddyWhistleItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        InteractionResult result = callBuddy(level, player);
        if (result == InteractionResult.PASS) {
            return InteractionResultHolder.pass(stack);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        InteractionResult result = callBuddy(context.getLevel(), context.getPlayer());
        return result == InteractionResult.PASS ? InteractionResult.PASS : InteractionResult.sidedSuccess(context.getLevel().isClientSide);
    }

    private InteractionResult callBuddy(Level level, Player player) {
        if (player == null || level.isClientSide) return InteractionResult.SUCCESS;
        AABB search = player.getBoundingBox().inflate(48.0D);
        var buddies = level.getEntitiesOfClass(CaveBuddyEntity.class, search,
                buddy -> buddy.isTame() && buddy.isOwnedBy(player));
        if (buddies.isEmpty()) return InteractionResult.PASS;

        for (CaveBuddyEntity buddy : buddies) {
            buddy.whistleTo(player);
        }
        player.displayClientMessage(net.minecraft.network.chat.Component.literal("§aYour Cave Buddy heard the whistle!"), true);
        return InteractionResult.SUCCESS;
    }
}
