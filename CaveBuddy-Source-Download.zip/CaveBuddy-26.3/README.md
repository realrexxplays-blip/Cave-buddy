# Cave Buddy — Minecraft Java 26.3 (NeoForge)

An original tiny cave companion mod. This project targets Minecraft **26.3** and NeoForge **26.3.0.95**, using **Java 25**.

## Included in this starter build
- A tameable Cave Buddy creature.
- Tame with glow berries.
- Follow, sit, and stay behavior.
- A spawn egg item.
- Warns its owner about nearby hostile mobs, nearby lava, and very dark surroundings.
- A whistle item to call your buddy (right-click while holding it).
- Custom model and texture resources.

## Build
1. Install a 64-bit Java 25 JDK.
2. Install Gradle 9.x or open this folder in IntelliJ IDEA with Gradle support.
3. Run `gradle build` from this folder.
4. The mod jar will be in `build/libs/`.

For a development client, run `gradle runClient`.

## Install
Put the built `cavebuddy-1.0.0.jar` into the `mods` folder of a Minecraft 26.3 profile that has the matching NeoForge 26.3 loader installed.

## Controls
- Feed a wild Cave Buddy **glow berries** to tame it.
- Right-click a tamed buddy with an empty hand to make it sit or follow.
- Hold the **Cave Buddy Whistle** and right-click to call your tamed buddy nearby.
- Crafting recipes are included for the whistle.

## Notes
This is a source project, not a prebuilt mod jar. It has not been compiled in this environment, so build verification still needs to be done with Java 25 and Gradle. NeoForge 26.3 is a newer modding target and its loader build may be marked beta by the NeoForge project.

## Build automatically on GitHub (no local Java/Gradle setup)
1. Create a new GitHub repository and upload the contents of this project.
2. Open the repository's **Actions** tab.
3. Select **Build Cave Buddy** and choose **Run workflow** (or push to `main`/`master`).
4. When the workflow finishes successfully, open the run and download the **CaveBuddy-1.0.0** artifact. It contains the mod JAR.

If the workflow fails, open the run's build log; the Java compiler output will show which source/API issue needs fixing. The workflow is a build attempt, not proof that the current source compiles.
